import '../assets/css/Footer.css';

function Footer() {
  return (
    <footer className="footer">
      <p>&copy; 2025 Mienimalis. Semua hak dilindungi.</p>
    </footer>
  );
}

export default Footer;
