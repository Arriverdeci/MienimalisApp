import '../assets/css/Hero.css';

function Hero() {
  return (
    <section className="hero">
      <div className="hero-container">
        <div className="hero-text">
          <h2>Mie Ayam Simpel, Rasa Maksimal</h2>
          <p>Cita rasa lokal dengan sentuhan modern. Cobain sekarang!</p>
          <button onClick={() => alert('Fitur belum tersedia')}>Pesan Sekarang</button>
        </div>
        <img src="src/assets/images/LogoApp.png" alt="Mie Ayam" className="hero-image" />
      </div>
    </section>
  );
}

export default Hero;
