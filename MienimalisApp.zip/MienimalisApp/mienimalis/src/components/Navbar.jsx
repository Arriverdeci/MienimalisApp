import { Link } from "react-router-dom";
import '../assets/css/Navbar.css';

function Navbar() {
  return (
    <header className="navbar">
      <div className="navbar-container">
        <h1 className="brand">Mienimalis</h1>
        <nav>
          <ul className="nav-links">
            <li><Link to="/">Home</Link></li>
            <li><Link to="/about">About</Link></li>
            <li><Link to="/menu">Menu</Link></li>
            <li><Link to="/pages">Pages</Link></li>
            <li><Link to="/contact">Contact</Link></li>
          </ul>
        </nav>
      </div>
    </header>
  );
}

export default Navbar;
