function MenuItem({ item }) {
  return (
    <div className="menu-item">
      <h3>{item.name}</h3>
      <p>{item.desc}</p>
      <span>Rp {item.price}</span>
    </div>
  );
}

export default MenuItem;
