import MenuItem from "../components/MenuItem";

const dummyMenu = [
  { id: 1, name: "Mi Ayam Original", price: "15.000", desc: "Mi ayam klasik dengan topping ayam manis gurih." },
  { id: 2, name: "Mi Ayam Bakso", price: "18.000", desc: "Mi ayam lengkap dengan bakso sapi kenyal." },
  { id: 3, name: "Mi Ayam Pedas", price: "17.000", desc: "Mi ayam dengan sambal khas pedas nendang!" },
];

function Menu() {
  return (
    <section className="menu-page container">
      <h2>Menu Mienimalis</h2>
      <div className="menu-grid">
        {dummyMenu.map(item => (
          <MenuItem key={item.id} item={item} />
        ))}
      </div>
    </section>
  );
}

export default Menu;
